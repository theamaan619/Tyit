/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.Registration;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    //private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get user input from the form
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String country = request.getParameter("country");

        // JDBC code to store the user data in the database
        String url = "jdbc:mysql://127.0.0.1:3306/userdb";  // Update with your database name and credentials
        String dbUsername = "root";  // Update with your MySQL username
        String dbPassword = "Amaan619";  // Update with your MySQL password

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            Connection conn = DriverManager.getConnection(url, dbUsername, dbPassword);

            // Insert query
            String query = "INSERT INTO users1 (username, password, email, country) VALUES (?, ?, ?, ?)";

            // Create PreparedStatement
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, email);
            stmt.setString(4, country);

            // Execute update
            int row = stmt.executeUpdate();

            // Close connection
            stmt.close();
            conn.close();

            if (row > 0) {
                out.println("<h2>Registration successful!</h2>");
            } else {
                out.println("<h2>Registration failed.</h2>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            out.println("<h2>Error occurred during registration. Please try again later.</h2>");
            out.print(e);
        }
    }
}
