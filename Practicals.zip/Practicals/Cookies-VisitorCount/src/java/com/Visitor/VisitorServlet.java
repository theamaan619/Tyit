/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.Visitor;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/visitCounter")
public class VisitorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get all the cookies from the request
        Cookie[] cookies = request.getCookies();
        int visitCount = 0;

        // Check if the visitCount cookie is present
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("visitCount")) {
                    // Retrieve visit count from the cookie
                    visitCount = Integer.parseInt(cookie.getValue());
                }
            }
        }

        // Increment the visit count
        visitCount++;

        // Create or update the cookie with the new visit count
        Cookie visitCookie = new Cookie("visitCount", Integer.toString(visitCount));
        visitCookie.setMaxAge(30);  // Cookie expires in 30 second
        response.addCookie(visitCookie);

        // Prepare the response
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Display the number of visits to the user
        out.println("<html><body>");
        out.println("<h1>Welcome Back!</h1>");
        if (visitCount == 1) {
            out.println("<p>This is your first visit to this page.</p>");
        } else {
            out.println("<p>You have visited this page " + visitCount + " times.</p>");
        }
        out.println("</body></html>");
    }
}
