/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.Convertor;

/**
 *
 * @author theam
 */
public class CCBean {

    
public CCBean() {
    }

    public double r2Dollor(double r) {
        return r / 65.65;
    }

    public double d2Rupees(double d) {
        return d * 65.65;
    }
}
