/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.Session;



import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/sessionServlet")
public class SessionServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Set the response content type to HTML
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get or create the session
        HttpSession session = request.getSession();

        // Check if the session is new
        if (session.isNew()) {
            // First time visiting the page
            out.println("<html><body>");
            out.println("<h1>Welcome!</h1>");
            out.println("<p>This is your first visit to this page.</p>");
            out.println("<p>Your session ID is: " + session.getId() + "</p>");
            out.println("</body></html>");
        } else {
            // User has visited before
            out.println("<html><body>");
            out.println("<h1>Welcome back!</h1>");
            out.println("<p>You have visited this page earlier.</p>");
            out.println("<p>Your session ID is: " + session.getId() + "</p>");
            out.println("<form action='sessionServlet' method='post'>");
            out.println("<input type='submit' value='End Session'>");
            out.println("</form>");
            out.println("</body></html>");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the current session
        HttpSession session = request.getSession(false);

        // If session exists, invalidate it to destroy the session
        if (session != null) {
            session.invalidate();
        }

        // Inform the user that the session is destroyed
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>Session Ended</h1>");
        out.println("<p>Your session has been destroyed. Visit the page again to create a new session.</p>");
        out.println("<a href='index.html'>Go Back to Home</a>");
        out.println("</body></html>");
    }
}
